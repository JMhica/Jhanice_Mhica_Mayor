﻿Public Class Form2
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles pw_lbl.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles cancel_btn.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles signup_btn.Click

    End Sub

    Private Sub un_txtbox_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class