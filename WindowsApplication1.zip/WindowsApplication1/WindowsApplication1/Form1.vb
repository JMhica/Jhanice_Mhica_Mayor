﻿Public Class Form1
    Private Sub login_btn_Click(sender As Object, e As EventArgs) Handles login_btn.Click
        MessageBox.Show("Hello World!")
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles un_lbl.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class
